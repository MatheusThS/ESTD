package agenda3;

import java.util.Objects;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Fone {

    private String id;
    private String numero;

    public Fone(String id, String numero) {
        this.id     = id;
        this.numero = numero;
    }

    /**
     * Vem no formato: {@code operadora:(xx)xxxx-xxxx}.
     */
    public Fone(String serial) {
        if (Validador.validarSerial(serial)) {
            id = serial.split(":")[0];
            setNumero(serial.split(":")[1]);
        } else {
            Logger.getAnonymousLogger()
                  .log(Level.WARNING, "O serial não está em um formato válido.");
        }
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getNumero() {
        return numero;
    }

    public void setNumero(String numero) {
        this.numero = numero.replaceAll("\\D", "");
    }

    @Override
    public int hashCode() {
        int result = (id != null)
                     ? id.hashCode()
                     : 0;
        result = (31 * result) + ((numero != null)
                                  ? numero.hashCode()
                                  : 0);
        return result;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        Fone fone = (Fone) o;

        return Objects.equals(id, fone.id) &&
               Objects.equals(numero, fone.numero);
    }

    @Override
    public String toString() {
        StringBuilder builder = new StringBuilder(numero);
        builder.insert(0, "(")
               .insert(3, ")")
               .insert(builder.length() - 4, "-");

        return "[" + id + ":" + builder + "]";
    }
}
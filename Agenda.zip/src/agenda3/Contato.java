package agenda3;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Objects;

public class Contato {

    private String     nome;
    private List<Fone> fones;

    public Contato(String nome) {
        this.nome  = nome;
        this.fones = new ArrayList<>();
    }

    public Contato(String nome, Fone... fones) {
        this(nome);
        this.fones = new ArrayList<>(Arrays.asList(fones));
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public List<Fone> getFones() {
        return fones;
    }

    public void setFones(List<Fone> fones) {
        this.fones = fones;
    }

    @Override
    public int hashCode() {
        return nome != null
               ? nome.hashCode()
               : 0;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        Contato contato = (Contato) o;

        return Objects.equals(nome, contato.nome);
    }

    @Override
    public String toString() {
        return "Contato{" +
               "nome='" + nome + '\'' +
               ", fones=" + fones +
               '}';
    }

    public void addFone(Fone fone) {
        fones.add(fone);
    }

    public void removeFone(Fone fone) {
        fones.remove(fone);
    }
}
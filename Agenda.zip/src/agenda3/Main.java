package agenda3;

import java.util.List;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Main {

    public static void main(String[] args) {
        Agenda   agenda  = new Agenda();
        Scanner  scanner = new Scanner(System.in);
        String   comando;
        String[] partes;

        boolean executar = true;

        System.out.println("add Adriano claro:(16)99751-3562");
        System.out.println("add Rafaela oi:(16)3242-8266");

        while (executar) {
            System.out.print("Comando: ");
            comando = scanner.nextLine();

            if (!Validador.validarComando(comando)) {
                Logger.getAnonymousLogger()
                      .log(Level.WARNING, "O comando não é válido.");
                continue;
            }

            partes = comando.split(" ");

            switch (partes[0]) {
                case "add":
                    Fone fone = new Fone(partes[2]);
                    Contato contato = new Contato(partes[1], fone);
                    agenda.addContato(contato);
                    break;
                case "show":
                    List<Contato> contatos = agenda.getContatos();
                    contatos.forEach(System.out::println);
                    System.out.println("Total: " + contatos.size());
                    break;
                case "exit":
                    executar = false;
                    break;
            }
        }

        System.exit(0);
    }
}
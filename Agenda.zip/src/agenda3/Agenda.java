package agenda3;

import java.util.ArrayList;
import java.util.List;

public class Agenda {

    private final List<Contato> contatos;

    public Agenda() {
        contatos = new ArrayList<>();
    }

    public List<Contato> getContatos() {
        return contatos;
    }

    @Override
    public String toString() {
        return "Agenda{" +
               "contatos=" + contatos +
               '}';
    }

    /**
     * Adiciona um novo contato na agenda, se o contato já existir, os números
     * serão adicionado ao contato existente.
     */
    public void addContato(Contato contato) {
        if (contatos.contains(contato)) {
            // Procedimento de merge
            Contato temp = contatos.get(contatos.indexOf(contato));
            temp.getFones().addAll(contato.getFones());
        } else {
            // Procedimento de add
            contatos.add(contato);
        }
    }

    public void removeContato(Contato contato) {
        contatos.remove(contato);
    }

    public void removeContato(String nome) {
        removeContato(new Contato(nome));
    }
}
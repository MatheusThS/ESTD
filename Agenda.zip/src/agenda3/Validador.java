package agenda3;

public class Validador {

    public static boolean validarComando(String comando) {
        return comando.matches("(add [a-z A-Z]{3,} .+|show|exit)");
    }

    public static boolean validarNumero(String numero) {
        return numero.replaceAll("\\D", "")
                     .matches("\\d{10,11}");
    }

    public static boolean validarSerial(String serial) {
        return serial.matches("\\D+:\\(?\\d{2}\\)?\\d{4,5}-?\\d{4}");
    }
}